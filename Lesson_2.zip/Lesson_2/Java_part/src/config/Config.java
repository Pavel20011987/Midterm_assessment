package config;

public class Config {

    public static String stockPath = "toys.csv";
    public static String prizePath = "prize.csv";
}
