package view;

public interface View {
    public void set(String string);

    public String get();
}
